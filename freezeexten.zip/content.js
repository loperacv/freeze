/* =======================================================================
 *  hoverFreeze.js – Improved hover elements detection and freeze
 * =======================================================================*/

// Global stylesheet for storing frozen styles
let frozenStylesheet = null;

// Creates a new stylesheet for frozen elements
function createFrozenStylesheet() {
    if (!frozenStylesheet) {
        frozenStylesheet = document.createElement('style');
        frozenStylesheet.id = '__freeze-stylesheet';
        document.head.appendChild(frozenStylesheet);
    }
    return frozenStylesheet;
}

// Removes the stylesheet when unfreezing
function removeFrozenStylesheet() {
    if (frozenStylesheet) {
        frozenStylesheet.remove();
        frozenStylesheet = null;
    }
}

// Checks if an element should be skipped (e.g., freeze button or hint)
function shouldSkipElement(node) {
    const freezeBtn = document.getElementById('__freezeBtn');
    const freezeHint = document.getElementById('__freezeHint');
    return node === freezeBtn || node === freezeHint ||
           (freezeBtn && freezeBtn.contains(node)) ||
           (freezeHint && freezeHint.contains(node));
}

// Freezes only the directly hovered element and its affected children
function freezeOnlyDirectHoverElement() {
    unfreezeAllHoveredStyles();

    const freezeBtn = document.getElementById('__freezeBtn');
    const freezeHint = document.getElementById('__freezeHint');
    const shouldSkip = node =>
        node === freezeBtn || node === freezeHint ||
        (freezeBtn && freezeBtn.contains(node)) ||
        (freezeHint && freezeHint.contains(node));

    let allHovered = document.querySelectorAll(':hover');
    if (allHovered.length === 0) {
        setTimeout(() => {
            allHovered = document.querySelectorAll(':hover');
            if (allHovered.length === 0) {
                return;
            }
            proceedWithHover(allHovered);
        }, 50);
        return;
    }

    proceedWithHover(allHovered);

    function proceedWithHover(hoveredElements) {
        let directHoverElement = hoveredElements[hoveredElements.length - 1];
        if (shouldSkip(directHoverElement)) {
            return;
        }

        if (directHoverElement.classList.contains('swiper-no-swiping') ||
            directHoverElement.closest('.swiper-slide')) {
            const swiperParent = directHoverElement.closest('.swiper-slide') || directHoverElement;
            directHoverElement = swiperParent.querySelector('button, .btn, [role="button"], .to-wishlist, .add-to-cart') || directHoverElement;
        }

        captureAndFreezeElement(directHoverElement);

        directHoverElement.querySelectorAll('*').forEach(child => {
            if (!shouldSkip(child)) {
                captureAndFreezeElement(child);
            }
        });

        const potentiallyAffectedElements = findPotentiallyAffectedElements(directHoverElement);

        potentiallyAffectedElements.forEach(element => {
            if (!shouldSkip(element)) {
                captureAndFreezeElement(element);
                element.querySelectorAll('*').forEach(child => {
                    if (!shouldSkip(child)) {
                        captureAndFreezeElement(child);
                    }
                });
            }
        });
    }
}

// Identifies elements potentially affected by the hover
function findPotentiallyAffectedElements(hoverElement) {
    const affected = new Set();
    checkParentsAndSiblings(hoverElement, affected);
    checkCSSHoverSelectors(hoverElement, affected);
    checkJavaScriptHoverListeners(hoverElement, affected);
    checkDynamicallyCreatedElements(hoverElement, affected);
    return Array.from(affected);
}

// Checks parents and siblings for visual changes
function checkParentsAndSiblings(hoverElement, affected) {
    let parent = hoverElement.parentElement;
    let depth = 0;

    while (parent && depth < 5) {
        if (!(parent instanceof Element)) {
            parent = parent.parentElement;
            depth++;
            continue;
        }

        if (isElementVisuallyChanged(parent)) {
            affected.add(parent);
        }

        Array.from(parent.children).forEach(sibling => {
            if (sibling !== hoverElement && isElementVisuallyChanged(sibling)) {
                affected.add(sibling);
            }
        });

        parent = parent.parentElement;
        depth++;
    }
}

// Checks for CSS hover selectors affecting the element
function checkCSSHoverSelectors(hoverElement, affected) {
    const hoverSelectors = [
        '[data-hover]', '[data-tooltip]', '[data-bs-toggle]', '[data-toggle]'
    ];

    try {
        const context = hoverElement.closest('div, section, article, .actions, .end, .swiper-slide');
        if (context) {
            hoverSelectors.forEach(selector => {
                try {
                    const elements = context.querySelectorAll(selector) || [];
                    elements.forEach(el => {
                        if (isElementVisuallyChanged(el) && getElementDistance(el, hoverElement) < 200) {
                            affected.add(el);
                            el.querySelectorAll('svg, path, circle, rect, g, polygon, polyline, line, ellipse').forEach(svgChild => {
                                if (isElementVisuallyChanged(svgChild)) {
                                    affected.add(svgChild);
                                }
                            });
                        }
                    });
                } catch (e) {}
            });
        }

        const maxSheetsToScan = 5;
        let sheetsScanned = 0;
        Array.from(document.styleSheets).some(sheet => {
            if (sheetsScanned >= maxSheetsToScan) return true;
            try {
                if (sheet.cssRules) {
                    Array.from(sheet.cssRules).forEach(rule => {
                        if (rule.selectorText?.toLowerCase().includes(':hover')) {
                            const baseSelector = rule.selectorText.split(':hover')[0].trim();
                            try {
                                const elements = context?.querySelectorAll(baseSelector) || [];
                                elements.forEach(el => {
                                    if (isElementVisuallyChanged(el) && getElementDistance(el, hoverElement) < 200) {
                                        affected.add(el);
                                        el.querySelectorAll('svg, path, circle, rect, g, polygon, polyline, line, ellipse').forEach(svgChild => {
                                            if (isElementVisuallyChanged(svgChild)) {
                                                affected.add(svgChild);
                                            }
                                        });
                                    }
                                });
                            } catch (e) {}
                        }
                    });
                    sheetsScanned++;
                }
            } catch (e) {}
            return false;
        });
    } catch (e) {}
}

// Checks for JavaScript hover event listeners
function checkJavaScriptHoverListeners(hoverElement, affected) {
    const nearbyElements = getNearbyElements(hoverElement, 100);
    const parentElements = [];
    let parent = hoverElement.parentElement;
    let depth = 0;

    while (parent && depth < 5) {
        parentElements.push(parent);
        parent = parent.parentElement;
        depth++;
    }

    [...nearbyElements, ...parentElements].forEach(element => {
        if (hasHoverRelatedListeners(element)) {
            affected.add(element);
            element.querySelectorAll('svg, path, circle, rect, g, polygon, polyline, line, ellipse').forEach(svgChild => {
                if (isElementVisuallyChanged(svgChild)) {
                    affected.add(svgChild);
                }
            });
        }
    });
}

// Detects dynamically created elements affected by hover
function checkDynamicallyCreatedElements(hoverElement, affected) {
    const recentlyVisible = document.querySelectorAll('[style*="display"], [style*="opacity"], [style*="visibility"]');

    recentlyVisible.forEach(element => {
        const style = element.getAttribute('style') || '';
        const cs = getComputedStyle(element);

        if ((style.includes('display') && cs.display !== 'none') ||
            (style.includes('opacity') && parseFloat(cs.opacity) > 0.1) ||
            (style.includes('visibility') && cs.visibility !== 'hidden')) {

            if (getElementDistance(element, hoverElement) < 300) {
                affected.add(element);
                element.querySelectorAll('svg, path, circle, rect, g, polygon, polyline, line, ellipse').forEach(svgChild => {
                    if (isElementVisuallyChanged(svgChild)) {
                        affected.add(svgChild);
                    }
                });
            }
        }
    });
}

// Determines if an element has visually significant changes
function isElementVisuallyChanged(element) {
    try {
        if (!(element instanceof Element) || typeof element.className !== 'string') {
            return false;
        }

        const cs = getComputedStyle(element);
        const hasActiveTransform = cs.transform !== 'none' && cs.transform !== 'matrix(1, 0, 0, 1, 0, 0)';
        const hasHighOpacity = parseFloat(cs.opacity) > 0.9;
        const hasHighZIndex = parseInt(cs.zIndex) > 10;
        const isVisible = cs.display !== 'none' && cs.visibility !== 'hidden';

        const hasHoverClass = element.className.includes('hover') ||
                              element.className.includes('active') ||
                              element.className.includes('focus') ||
                              element.className.includes('dropdown') ||
                              element.className.includes('tooltip') ||
                              element.className.includes('popover') ||
                              element.className.includes('swiper');

        const isSVGElement = element.tagName.toLowerCase() === 'svg' || element.tagName.toLowerCase() === 'path' ||
                            element.tagName.toLowerCase() === 'circle' || element.tagName.toLowerCase() === 'rect' ||
                            element.tagName.toLowerCase() === 'g' || element.tagName.toLowerCase() === 'polygon' ||
                            element.tagName.toLowerCase() === 'polyline' || element.tagName.toLowerCase() === 'line' ||
                            element.tagName.toLowerCase() === 'ellipse' || element.closest('svg');

        let hasSVGChanges = false;
        if (isSVGElement) {
            const fill = element.getAttribute('fill') || cs.fill || 'currentColor';
            const stroke = element.getAttribute('stroke') || cs.stroke || 'currentColor';
            const parentColor = element.closest('[style*="color"], button, .btn, [role="button"]')?.style.color ||
                               getComputedStyle(element.parentElement).color;

            hasSVGChanges = element.closest(':hover') !== null && (
                (fill === 'currentColor' && parentColor && parentColor !== 'rgba(0, 0, 0, 0)') ||
                (stroke === 'currentColor' && parentColor && parentColor !== 'rgba(0, 0, 0, 0)') ||
                (fill !== 'none' && fill !== 'transparent') ||
                (stroke !== 'none' && stroke !== 'transparent') ||
                element.hasAttribute('fill') ||
                element.hasAttribute('stroke') ||
                element.style.fill ||
                element.style.stroke
            );
        }

        const isIconContainer = element.classList.contains('icon') ||
                               element.classList.contains('icon-inner') ||
                               element.classList.contains('icon-box-img') ||
                               element.classList.contains('has-icon-bg') ||
                               element.classList.contains('btn') ||
                               element.classList.contains('button') ||
                               element.classList.contains('to-wishlist') ||
                               element.classList.contains('add-to-cart') ||
                               element.querySelector('svg') !== null;

        let hasIconChanges = false;
        if (isIconContainer) {
            const bgColor = cs.backgroundColor;
            const hasVisibleBackground = bgColor && bgColor !== 'rgba(0, 0, 0, 0)' &&
                                       bgColor !== 'transparent' && bgColor !== 'none';

            const borderColor = cs.borderColor;
            const borderWidth = cs.borderWidth;
            const hasVisibleBorder = borderColor && borderColor !== 'rgba(0, 0, 0, 0)' &&
                                   borderWidth && borderWidth !== '0px';

            const color = cs.color;
            const hasColorChange = color && color !== 'rgba(0, 0, 0, 0)' && color !== 'transparent';

            hasIconChanges = hasVisibleBackground || hasVisibleBorder || hasColorChange;
        }

        return isVisible && (hasActiveTransform || hasHighZIndex || hasHoverClass ||
                           hasSVGChanges || hasIconChanges);

    } catch (e) {
        return false;
    }
}

// Finds nearby elements within a given radius
function getNearbyElements(centerElement, radius) {
    try {
        const centerRect = centerElement.getBoundingClientRect();
        const centerX = centerRect.left + centerRect.width / 2;
        const centerY = centerRect.top + centerRect.height / 2;

        const nearbyElements = [];
        const allElements = document.querySelectorAll('*');

        for (let element of allElements) {
            if (element === centerElement) continue;

            const rect = element.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) continue;

            const elementX = rect.left + rect.width / 2;
            const elementY = rect.top + rect.height / 2;
            const distance = Math.sqrt(Math.pow(elementX - centerX, 2) + Math.pow(elementY - centerY, 2));

            if (distance <= radius) {
                nearbyElements.push(element);
            }
        }

        return nearbyElements;
    } catch (e) {
        return [];
    }
}

// Checks if an element has hover-related event listeners
function hasHoverRelatedListeners(element) {
    return element.onclick ||
           element.onmouseover ||
           element.onmouseout ||
           element.onmouseenter ||
           element.onmouseleave ||
           element.hasAttribute('data-hover') ||
           element.hasAttribute('data-tooltip') ||
           element.hasAttribute('data-bs-toggle') ||
           element.hasAttribute('data-toggle') ||
           element.getAttribute('role') === 'button' ||
           element.classList.contains('btn') ||
           element.classList.contains('button') ||
           element.classList.contains('to-wishlist') ||
           element.classList.contains('add-to-cart') ||
           element.classList.contains('swiper-no-swiping') ||
           getComputedStyle(element).cursor === 'pointer';
}

// Captures and applies freeze styles to an element
function captureAndFreezeElement(element) {
    if (element.hasAttribute('data-freeze-captured')) return;

    const freezeClass = `__freeze-${Math.random().toString(36).substr(2, 9)}`;
    element.classList.add(freezeClass);

    const origStyle = element.getAttribute('style') || '';
    element.setAttribute('data-orig-style', origStyle);
    element.setAttribute('data-freeze-captured', 'true');

    const computed = getComputedStyle(element);
    let freezeStyles = '';

    const allCriticalProps = [
        'display', 'opacity', 'visibility', 'overflow', 'overflow-x', 'overflow-y',
        'color', 'background', 'background-color', 'background-image', 'background-position',
        'background-size', 'background-repeat', 'background-attachment', 'background-clip',
        'border', 'border-top', 'border-right', 'border-bottom', 'border-left',
        'border-radius', 'border-color', 'border-width', 'border-style',
        'outline', 'outline-color', 'outline-width', 'outline-style',
        'width', 'height', 'min-width', 'min-height', 'max-width', 'max-height',
        'position', 'top', 'left', 'bottom', 'right', 'z-index',
        'padding', 'padding-top', 'padding-right', 'padding-bottom', 'padding-left',
        'margin', 'margin-top', 'margin-right', 'margin-bottom', 'margin-left',
        'transform', 'transform-origin', 'transform-style', 'perspective',
        'box-shadow', 'text-shadow', 'filter', 'backdrop-filter',
        'font', 'font-size', 'font-family', 'font-weight', 'font-style', 'line-height',
        'text-align', 'text-decoration', 'text-transform', 'letter-spacing', 'word-spacing',
        'text-indent', 'white-space', 'word-wrap', 'word-break',
        'flex', 'flex-direction', 'flex-wrap', 'flex-grow', 'flex-shrink', 'flex-basis',
        'align-items', 'align-content', 'align-self', 'justify-content', 'justify-items', 'justify-self',
        'gap', 'row-gap', 'column-gap', 'order',
        'grid', 'grid-template', 'grid-template-columns', 'grid-template-rows', 'grid-area',
        'grid-column', 'grid-row', 'grid-auto-flow', 'grid-auto-columns', 'grid-auto-rows',
        'fill', 'stroke', 'stroke-width', 'stroke-dasharray', 'stroke-dashoffset',
        'stroke-linecap', 'stroke-linejoin', 'fill-opacity', 'stroke-opacity',
        'cursor', 'pointer-events', 'user-select', 'resize', 'content',
        'list-style', 'list-style-type', 'list-style-position', 'list-style-image'
    ];

    allCriticalProps.forEach(prop => {
        try {
            const value = computed.getPropertyValue(prop);
            if (value && value !== 'normal' && value !== 'auto' && value !== 'initial' &&
                value !== 'none' && value !== '' && value !== '0px' && value !== 'rgba(0, 0, 0, 0)') {
                freezeStyles += `${prop}: ${value} !important; `;
            }
        } catch (e) {}
    });

    const isSVGElement = element.tagName.toLowerCase() === 'svg' || element.tagName.toLowerCase() === 'path' ||
                        element.tagName.toLowerCase() === 'circle' || element.tagName.toLowerCase() === 'rect' ||
                        element.tagName.toLowerCase() === 'g' || element.tagName.toLowerCase() === 'polygon' ||
                        element.tagName.toLowerCase() === 'polyline' || element.tagName.toLowerCase() === 'line' ||
                        element.tagName.toLowerCase() === 'ellipse' || element.closest('svg');

    if (isSVGElement) {
        const svgAttribs = ['fill', 'stroke', 'stroke-width', 'opacity', 'fill-opacity', 'stroke-opacity'];
        svgAttribs.forEach(attr => {
            const value = element.getAttribute(attr);
            if (value) {
                element.setAttribute(`data-orig-${attr}`, value);
            }
        });

        const currentFill = computed.fill || element.getAttribute('fill') || 'currentColor';
        const currentStroke = computed.stroke || element.getAttribute('stroke') || 'currentColor';
        const currentOpacity = computed.opacity || element.getAttribute('opacity');

        if (currentFill === 'currentColor') {
            const parentColor = computed.color || getComputedStyle(element.parentElement).color;
            if (parentColor && parentColor !== 'rgba(0, 0, 0, 0)') {
                freezeStyles += `fill: ${parentColor} !important; `;
            }
        } else if (currentFill && currentFill !== 'none' && currentFill !== 'transparent') {
            freezeStyles += `fill: ${currentFill} !important; `;
        }

        if (currentStroke === 'currentColor') {
            const parentColor = computed.color || getComputedStyle(element.parentElement).color;
            if (parentColor && parentColor !== 'rgba(0, 0, 0, 0)') {
                freezeStyles += `stroke: ${parentColor} !important; `;
            }
        } else if (currentStroke && currentStroke !== 'none' && currentStroke !== 'transparent') {
            freezeStyles += `stroke: ${currentStroke} !important; `;
        }

        if (currentOpacity && currentOpacity !== '1') {
            freezeStyles += `opacity: ${currentOpacity} !important; `;
        }
    }

    const isIconContainer = element.classList.contains('icon') ||
                           element.classList.contains('icon-inner') ||
                           element.classList.contains('icon-box-img') ||
                           element.classList.contains('has-icon-bg') ||
                           element.classList.contains('btn') ||
                           element.classList.contains('button') ||
                           element.classList.contains('to-wishlist') ||
                           element.classList.contains('add-to-cart') ||
                           element.querySelector('svg') !== null;

    if (isIconContainer) {
        const backgroundProps = ['background', 'background-color', 'background-image'];
        backgroundProps.forEach(prop => {
            const value = computed.getPropertyValue(prop);
            if (value && value !== 'none' && value !== 'transparent' && value !== 'rgba(0, 0, 0, 0)') {
                freezeStyles += `${prop}: ${value} !important; `;
            }
        });

        const borderRadius = computed.getPropertyValue('border-radius');
        if (borderRadius && borderRadius !== '0px') {
            freezeStyles += `border-radius: ${borderRadius} !important; `;
        }

        const borderProps = ['border', 'border-color', 'border-width', 'border-style'];
        borderProps.forEach(prop => {
            const value = computed.getPropertyValue(prop);
            if (value && value !== 'none' && value !== '0px' && value !== 'transparent') {
                freezeStyles += `${prop}: ${value} !important; `;
            }
        });

        const color = computed.getPropertyValue('color');
        if (color && color !== 'rgba(0, 0, 0, 0)' && color !== 'transparent') {
            freezeStyles += `color: ${color} !important; `;
        }
    }

    freezeStyles += 'transition: none !important; ';
    freezeStyles += 'animation: none !important; ';
    freezeStyles += 'animation-play-state: paused !important; ';

    const stylesheet = createFrozenStylesheet();
    try {
        stylesheet.sheet.insertRule(`.${freezeClass} { ${freezeStyles} }`, stylesheet.sheet.cssRules.length);
    } catch (e) {}
}

// Calculates the distance between two elements
function getElementDistance(el1, el2) {
    try {
        const rect1 = el1.getBoundingClientRect();
        const rect2 = el2.getBoundingClientRect();

        const x1 = rect1.left + rect1.width / 2;
        const y1 = rect1.top + rect1.height / 2;
        const x2 = rect2.left + rect2.width / 2;
        const y2 = rect2.top + rect2.height / 2;

        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    } catch (e) {
        return Infinity;
    }
}

// Unfreezes all previously frozen elements
function unfreezeAllHoveredStyles() {
    document.querySelectorAll('iframe[data-freeze-iframe]').forEach(iframe => {
        const origStyle = iframe.getAttribute('data-orig-iframe-style') || '';
        iframe.setAttribute('style', origStyle);
        iframe.removeAttribute('data-freeze-iframe');
        iframe.removeAttribute('data-orig-iframe-style');
    });

    document.querySelectorAll('[data-freeze-captured]').forEach(element => {
        const origStyle = element.getAttribute('data-orig-style');
        if (typeof origStyle === 'string') {
            element.setAttribute('style', origStyle);
        } else {
            element.removeAttribute('style');
        }

        const classes = Array.from(element.classList);
        classes.forEach(cls => {
            if (cls.startsWith('__freeze-')) {
                element.classList.remove(cls);
            }
        });

        const svgAttribs = ['fill', 'stroke', 'stroke-width', 'opacity', 'fill-opacity', 'stroke-opacity'];
        svgAttribs.forEach(attr => {
            const origValue = element.getAttribute(`data-orig-${attr}`);
            if (origValue !== null) {
                element.setAttribute(attr, origValue);
                element.removeAttribute(`data-orig-${attr}`);
            } else {
                if (element.hasAttribute(attr) && !element.getAttribute(attr)?.includes('currentColor')) {
                    element.removeAttribute(attr);
                }
            }
        });

        element.removeAttribute('data-freeze-style');
        element.removeAttribute('data-orig-style');
        element.removeAttribute('data-freeze-captured');
    });

    removeFrozenStylesheet();
}

/* =======================================================================
 *  pageFreeze.js – Page freezing UI and event handling
 * =======================================================================*/

const BTN_CSS = `
    position:fixed !important; top:22px !important; right:22px !important;
    z-index:2147483647 !important; pointer-events:auto !important;
    display:flex !important; flex-direction:column !important; align-items:center !important;
    justify-content:center !important; padding:0 !important; border:1px solid rgba(255,255,255,.28) !important;
    border-radius:18px !important; font:600 13px/1 sans-serif !important;
    color:#fff !important; cursor:pointer !important;
    box-shadow:0 10px 30px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.22) !important;
    transition:transform .16s ease,box-shadow .16s ease,background .16s ease !important;
    user-select:none !important; width:58px !important; height:58px !important;
    min-width:58px !important; max-width:58px !important; min-height:58px !important;
    backdrop-filter:blur(12px) !important; -webkit-backdrop-filter:blur(12px) !important;
    overflow:visible !important;
`;

const COLORS = {
    freeze   : {
        bg:'linear-gradient(145deg,#667085 0%,#344054 100%)',
        drag:'#475467',
        icon:'#ffffff'
    },
    unfreeze : {
        bg:'linear-gradient(145deg,#12b76a 0%,#039855 100%)',
        drag:'#039855',
        icon:'#ffffff'
    }
};
const LONG_PRESS = 350;
const FREEZE_FLOAT_CSS = `
    #__freezeBtn {
        box-sizing:border-box !important;
        isolation:isolate !important;
        touch-action:none !important;
        -webkit-tap-highlight-color:transparent !important;
    }
    #__freezeBtn:hover { filter:saturate(1.12) brightness(1.05) !important; }
    #__freezeBtn:active { transform:scale(.96) !important; }
    #__freezeBtn:focus-visible {
        outline:2px solid rgba(84,214,255,.95) !important;
        outline-offset:3px !important;
    }
`;


const FREEZE_ICON = `
<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"
     style="display:block;pointer-events:none;fill:none;stroke:currentColor;
            stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round;">
    <path d="M12 2v20M4.93 5.93l14.14 12.14M4.93 18.07L19.07 5.93M2 12h20"/>
    <path d="M8.5 3.7 12 7.2l3.5-3.5M8.5 20.3 12 16.8l3.5 3.5"/>
</svg>`;

const UNFREEZE_ICON = `
<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"
     style="display:block;pointer-events:none;fill:none;stroke:currentColor;
            stroke-width:2;stroke-linecap:round;stroke-linejoin:round;">
    <path d="M7 4v16l13-8L7 4z" fill="currentColor" stroke="none"/>
</svg>`;

// Toggles the freeze button and its functionality
function setFreezeButton(enabled) {
    const setBtnVisual = (frozen, btn, hint) => {
        const c = frozen ? COLORS.unfreeze : COLORS.freeze;
        btn.style.backgroundImage = c.bg;
        btn.style.color = c.icon;
        btn.setAttribute('aria-label', frozen ? 'Unfreeze page' : 'Freeze page');
        btn.title = frozen
            ? 'Unfreeze page • Press Esc'
            : 'Freeze page • Shift + Ctrl';
        btn.dataset.dragColor = c.drag;

        const icon = btn.querySelector('.__freezeIcon');
        if (icon) icon.innerHTML = frozen ? UNFREEZE_ICON : FREEZE_ICON;

        if (hint) {
            hint.textContent = frozen ? 'ESC' : 'FREEZE';
        }
    };

    // Fully unfreezes the page and removes UI elements
    function fullUnfreeze(force = false) {
        unfreezeAllHoveredStyles();
        if (!window.__freezeYP2 && !force) return;
        window.__frozenRestoreFns?.forEach(fn => { try { fn(); } catch {} });
        window.__frozenRestoreFns = [];
        window.__frozenStyleElm?.remove(); window.__frozenStyleElm = null;
        if (window.__frozenTimers) {
            const { rafOrig, toOrig, intOrig } = window.__frozenTimers;
            rafOrig && (window.requestAnimationFrame = rafOrig);
            toOrig && (window.setTimeout = toOrig);
            intOrig && (window.setInterval = intOrig);
            window.__frozenTimers = null;
        }
        const freezeBtn = document.getElementById('__freezeBtn');
        const freezeHint = document.getElementById('__freezeHint');
        freezeBtn?.remove();
        freezeHint?.remove();
        window.__freezeIsFrozen = false;
        window.__freezeYP2 = false;
    }

    if (enabled) {
        if (document.getElementById('__freezeBtn') || window.__freezeYP2) return;
        window.__freezeYP2 = true;

        const btn = document.createElement('button');
        btn.id = '__freezeBtn';
        btn.type = 'button';
        btn.style.cssText = BTN_CSS;
        btn.setAttribute('data-freeze-floating', 'true');
        const independentStyle = document.createElement('style');
        independentStyle.id = '__freeze-independent-style';
        independentStyle.textContent = FREEZE_FLOAT_CSS;
        (document.head || document.documentElement).appendChild(independentStyle);

        const iconWrap = document.createElement('span');
        iconWrap.className = '__freezeIcon';
        iconWrap.style.cssText = 'display:flex;align-items:center;justify-content:center;width:100%;height:100%;pointer-events:none;';
        iconWrap.innerHTML = FREEZE_ICON;
        btn.append(iconWrap);

        const hint = document.createElement('span');
        hint.id = '__freezeHint';
        hint.style.cssText = `
            position:absolute !important; bottom:-22px !important; left:50% !important;
            transform:translateX(-50%) !important; padding:4px 7px !important;
            border-radius:6px !important; background:rgba(16,24,40,.88) !important;
            color:#fff !important; font:700 9px/1 sans-serif !important;
            letter-spacing:.45px !important; white-space:nowrap !important;
            opacity:0 !important; transition:opacity .15s ease !important;
            pointer-events:none !important;
        `;
        btn.append(hint);
        setBtnVisual(false, btn, hint);

        (document.documentElement || document.body).appendChild(btn);

        btn.addEventListener('mouseenter', () => {
            btn.style.transform = 'translateY(-3px) scale(1.04)';
            btn.style.boxShadow = '0 14px 34px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.24)';
            hint.style.opacity = '1';
        });
        btn.addEventListener('mouseleave', () => {
            btn.style.transform = '';
            btn.style.boxShadow = '0 10px 30px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.22)';
            hint.style.opacity = '0';
        });

        const blockedCapture = [
            'mouseout', 'mouseleave', 'mouseover', 'blur', 'focusout',
            'scroll', 'wheel', 'touchstart', 'touchmove', 'touchend',
            'pointerdown', 'pointermove', 'pointerup', 'pointercancel',
            'mousedown', 'mousemove', 'mouseup', 'click', 'dblclick'
        ];
        const blockedTimers = true, blockCSSAnim = true;
        let isFrozen = false, restoreFns = [], styleElm = null;
        let rafOrig, toOrig, intOrig;

        const stopper = e => {
            if (e.target === btn || e.target.closest?.('#yp-wrapper')) return;
            e.stopImmediatePropagation(); if (e.cancelable) e.preventDefault();
        };

        // Freezes the page by blocking events and animations
        function freeze() {
            if (isFrozen) return;
            isFrozen = true; window.__freezeIsFrozen = true; window.__frozenRestoreFns = restoreFns;

            freezeOnlyDirectHoverElement();

            document.querySelectorAll('iframe').forEach(iframe => {
                const origStyle = iframe.getAttribute('style') || '';
                iframe.setAttribute('data-orig-iframe-style', origStyle);
                iframe.setAttribute('data-freeze-iframe', 'true');
                iframe.style.pointerEvents = 'none';
            });

            [window, document, document.body].forEach(obj => {
                blockedCapture.forEach(ev => {
                    obj.addEventListener(ev, stopper, { capture: true, passive: false });
                    restoreFns.push(() => obj.removeEventListener(ev, stopper, { capture: true }));
                });
            });

            if (blockCSSAnim) {
                styleElm = document.createElement('style');
                styleElm.textContent = '*,*::before,*::after{transition:none!important;animation:none!important}';
                document.head.appendChild(styleElm); window.__frozenStyleElm = styleElm;
            }

            if (blockedTimers) {
                try { let id = setTimeout(() => {}, 0); while (id) clearTimeout(id--); } catch {}
                try { let id = setInterval(() => {}, 0); while (id) clearInterval(id--); } catch {}
                rafOrig = window.requestAnimationFrame; toOrig = window.setTimeout; intOrig = window.setInterval;
                window.requestAnimationFrame = () => 0;
                window.setTimeout = () => 0;
                window.setInterval = () => 0;
                window.__frozenTimers = { rafOrig, toOrig, intOrig };
            }
            setBtnVisual(true, btn, hint);
        }

        // Unfreezes the page and restores original state
        function unfreeze(force = false) {
            if (!isFrozen && !force) return;
            isFrozen = false; window.__freezeIsFrozen = false;

            unfreezeAllHoveredStyles();

            restoreFns.forEach(fn => { try { fn(); } catch {} });
            restoreFns = []; styleElm?.remove(); styleElm = null;

            if (blockedTimers) {
                rafOrig && (window.requestAnimationFrame = rafOrig);
                toOrig && (window.setTimeout = toOrig);
                intOrig && (window.setInterval = intOrig);
            }
            setBtnVisual(false, btn, hint);
        }

        let pressT, drag = false, badge = null, sx = 0, sy = 0, sl = 0, st = 0;

        btn.addEventListener('pointerdown', e => {
            drag = false; sx = e.clientX; sy = e.clientY;
            const r = btn.getBoundingClientRect(); sl = r.left; st = r.top;

            pressT = setTimeout(() => {
                drag = true;
                btn.style.left = sl + 'px'; btn.style.top = st + 'px'; btn.style.right = '';
                btn.style.transition = 'none'; btn.style.cursor = 'grabbing';
                btn.style.zIndex = '2147483647';
                btn.setPointerCapture(e.pointerId);

                if (!badge) {
                    badge = document.createElement('span'); badge.textContent = '↕';
                    Object.assign(badge.style, {
                        position: 'absolute', top: '-8px', right: '-8px',
                        width: '20px', height: '20px', background: '#fff',
                        color: btn.dataset.dragColor, border: `2px solid ${btn.dataset.dragColor}`,
                        borderRadius: '50%', fontSize: '11px', lineHeight: '16px', fontWeight: '800',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        pointerEvents: 'none', boxShadow: '0 1px 4px rgba(0,0,0,.25)'
                    });
                    btn.append(badge);
                }
            }, LONG_PRESS);

            e.stopPropagation();
            if (e.cancelable) e.preventDefault();
        }, true);

        btn.addEventListener('pointermove', e => {
            if (!drag) return;
            btn.style.left = (sl + e.clientX - sx) + 'px';
            btn.style.top = (st + e.clientY - sy) + 'px';
        }, true);

        btn.addEventListener('pointerup', e => {
            clearTimeout(pressT);
            if (drag) {
                drag = false; btn.releasePointerCapture(e.pointerId);
                btn.style.transition = ''; btn.style.cursor = 'pointer';
                badge?.remove(); badge = null;
            } else {
                isFrozen ? unfreeze() : freeze();
            }
        }, true);

        const handleKeydown = e => {
            window.top.focus();
            if (!isFrozen && e.shiftKey && e.ctrlKey && !e.altKey &&
                (e.key === 'Shift' || e.key === 'Control')) {
                freeze();
                e.stopImmediatePropagation();
                e.preventDefault();
            } else if (isFrozen && (e.key === 'Escape' || e.code === 'Escape')) {
                unfreeze();
                e.stopImmediatePropagation();
                e.preventDefault();
            }
        };

        const registerKeydownListeners = () => {
            window.removeEventListener('keydown', handleKeydown, { capture: true });
            document.removeEventListener('keydown', handleKeydown, { capture: true });
            window.addEventListener('keydown', handleKeydown, { capture: true, passive: false });
            document.addEventListener('keydown', handleKeydown, { capture: true, passive: false });
        };

        registerKeydownListeners();

        setTimeout(() => { if (isFrozen) unfreeze(true); }, 6 * 60 * 1000);
    } else {
        fullUnfreeze(true);
    }
}

// Initialize
chrome.storage.local.get('freezeGlobalEnabled', ({ freezeGlobalEnabled }) => {
    setFreezeButton(freezeGlobalEnabled);
});
chrome.runtime.onMessage.addListener(msg => {
    if (msg?.action === 'toggle-freeze') setFreezeButton(msg.enabled);
});