/* =======================================================================
 *  pageFreeze.js – Page freezing UI and event handling
 * =======================================================================*/

const BTN_CSS = `
    position:fixed !important; top:22px !important; right:22px !important;
    z-index:2147483647 !important; pointer-events:auto !important;
    display:flex !important; flex-direction:column !important; align-items:center !important;
    justify-content:center !important; padding:0 !important; border:1px solid rgba(255,255,255,.28) !important;
    border-radius:18px !important; font:600 13px/1 sans-serif !important;
    color:#fff !important; cursor:pointer !important;
    box-shadow:0 10px 30px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.22) !important;
    transition:transform .16s ease,box-shadow .16s ease,background .16s ease !important;
    user-select:none !important; width:58px !important; height:58px !important;
    min-width:58px !important; max-width:58px !important; min-height:58px !important;
    backdrop-filter:blur(12px) !important; -webkit-backdrop-filter:blur(12px) !important;
    overflow:visible !important;
`;

const COLORS = {
    freeze   : {
        bg:'linear-gradient(145deg,#667085 0%,#344054 100%)',
        drag:'#475467',
        icon:'#ffffff'
    },
    unfreeze : {
        bg:'linear-gradient(145deg,#12b76a 0%,#039855 100%)',
        drag:'#039855',
        icon:'#ffffff'
    }
};
const LONG_PRESS = 350;
const FREEZE_FLOAT_CSS = `
    #__freezeBtn {
        box-sizing:border-box !important;
        isolation:isolate !important;
        touch-action:none !important;
        -webkit-tap-highlight-color:transparent !important;
    }
    #__freezeBtn:hover { filter:saturate(1.12) brightness(1.05) !important; }
    #__freezeBtn:active { transform:scale(.96) !important; }
    #__freezeBtn:focus-visible {
        outline:2px solid rgba(84,214,255,.95) !important;
        outline-offset:3px !important;
    }
`;


const FREEZE_ICON = `
<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"
     style="display:block;pointer-events:none;fill:none;stroke:currentColor;
            stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round;">
    <path d="M12 2v20M4.93 5.93l14.14 12.14M4.93 18.07L19.07 5.93M2 12h20"/>
    <path d="M8.5 3.7 12 7.2l3.5-3.5M8.5 20.3 12 16.8l3.5 3.5"/>
</svg>`;

const UNFREEZE_ICON = `
<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"
     style="display:block;pointer-events:none;fill:none;stroke:currentColor;
            stroke-width:2;stroke-linecap:round;stroke-linejoin:round;">
    <path d="M7 4v16l13-8L7 4z" fill="currentColor" stroke="none"/>
</svg>`;

// Toggles the freeze button and its functionality
function setFreezeButton(enabled) {
    const setBtnVisual = (frozen, btn, hint) => {
        const c = frozen ? COLORS.unfreeze : COLORS.freeze;
        btn.style.backgroundImage = c.bg;
        btn.style.color = c.icon;
        btn.setAttribute('aria-label', frozen ? 'Unfreeze page' : 'Freeze page');
        btn.title = frozen
            ? 'Unfreeze page • Press Esc'
            : 'Freeze page • Shift + Ctrl';
        btn.dataset.dragColor = c.drag;

        const icon = btn.querySelector('.__freezeIcon');
        if (icon) icon.innerHTML = frozen ? UNFREEZE_ICON : FREEZE_ICON;

        if (hint) {
            hint.textContent = frozen ? 'ESC' : 'FREEZE';
        }
    };

    // Fully unfreezes the page and removes UI elements
    function fullUnfreeze(force = false) {
        unfreezeAllHoveredStyles();
        if (!window.__freezeYP2 && !force) return;
        window.__frozenRestoreFns?.forEach(fn => { try { fn(); } catch {} });
        window.__frozenRestoreFns = [];
        window.__frozenStyleElm?.remove(); window.__frozenStyleElm = null;
        if (window.__frozenTimers) {
            const { rafOrig, toOrig, intOrig } = window.__frozenTimers;
            rafOrig && (window.requestAnimationFrame = rafOrig);
            toOrig && (window.setTimeout = toOrig);
            intOrig && (window.setInterval = intOrig);
            window.__frozenTimers = null;
        }
        const freezeBtn = document.getElementById('__freezeBtn');
        const freezeHint = document.getElementById('__freezeHint');
        freezeBtn?.remove();
        freezeHint?.remove();
        window.__freezeIsFrozen = false;
        window.__freezeYP2 = false;
    }

    if (enabled) {
        if (document.getElementById('__freezeBtn') || window.__freezeYP2) return;
        window.__freezeYP2 = true;

        const btn = document.createElement('button');
        btn.id = '__freezeBtn';
        btn.type = 'button';
        btn.style.cssText = BTN_CSS;
        btn.setAttribute('data-freeze-floating', 'true');
        const independentStyle = document.createElement('style');
        independentStyle.id = '__freeze-independent-style';
        independentStyle.textContent = FREEZE_FLOAT_CSS;
        (document.head || document.documentElement).appendChild(independentStyle);

        const iconWrap = document.createElement('span');
        iconWrap.className = '__freezeIcon';
        iconWrap.style.cssText = 'display:flex;align-items:center;justify-content:center;width:100%;height:100%;pointer-events:none;';
        iconWrap.innerHTML = FREEZE_ICON;
        btn.append(iconWrap);

        const hint = document.createElement('span');
        hint.id = '__freezeHint';
        hint.style.cssText = `
            position:absolute !important; bottom:-22px !important; left:50% !important;
            transform:translateX(-50%) !important; padding:4px 7px !important;
            border-radius:6px !important; background:rgba(16,24,40,.88) !important;
            color:#fff !important; font:700 9px/1 sans-serif !important;
            letter-spacing:.45px !important; white-space:nowrap !important;
            opacity:0 !important; transition:opacity .15s ease !important;
            pointer-events:none !important;
        `;
        btn.append(hint);
        setBtnVisual(false, btn, hint);

        (document.documentElement || document.body).appendChild(btn);

        btn.addEventListener('mouseenter', () => {
            btn.style.transform = 'translateY(-3px) scale(1.04)';
            btn.style.boxShadow = '0 14px 34px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.24)';
            hint.style.opacity = '1';
        });
        btn.addEventListener('mouseleave', () => {
            btn.style.transform = '';
            btn.style.boxShadow = '0 10px 30px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.22)';
            hint.style.opacity = '0';
        });

        const blockedCapture = [
            'mouseout', 'mouseleave', 'mouseover', 'blur', 'focusout',
            'scroll', 'wheel', 'touchstart', 'touchmove', 'touchend',
            'pointerdown', 'pointermove', 'pointerup', 'pointercancel',
            'mousedown', 'mousemove', 'mouseup', 'click', 'dblclick'
        ];
        const blockedTimers = true, blockCSSAnim = true;
        let isFrozen = false, restoreFns = [], styleElm = null;
        let rafOrig, toOrig, intOrig;

        const stopper = e => {
            if (e.target === btn || e.target.closest?.('#yp-wrapper')) return;
            e.stopImmediatePropagation(); if (e.cancelable) e.preventDefault();
        };

        // Freezes the page by blocking events and animations
        function freeze() {
            if (isFrozen) return;
            isFrozen = true; window.__freezeIsFrozen = true; window.__frozenRestoreFns = restoreFns;

            freezeOnlyDirectHoverElement();

            document.querySelectorAll('iframe').forEach(iframe => {
                const origStyle = iframe.getAttribute('style') || '';
                iframe.setAttribute('data-orig-iframe-style', origStyle);
                iframe.setAttribute('data-freeze-iframe', 'true');
                iframe.style.pointerEvents = 'none';
            });

            [window, document, document.body].forEach(obj => {
                blockedCapture.forEach(ev => {
                    obj.addEventListener(ev, stopper, { capture: true, passive: false });
                    restoreFns.push(() => obj.removeEventListener(ev, stopper, { capture: true }));
                });
            });

            if (blockCSSAnim) {
                styleElm = document.createElement('style');
                styleElm.textContent = '*,*::before,*::after{transition:none!important;animation:none!important}';
                document.head.appendChild(styleElm); window.__frozenStyleElm = styleElm;
            }

            if (blockedTimers) {
                try { let id = setTimeout(() => {}, 0); while (id) clearTimeout(id--); } catch {}
                try { let id = setInterval(() => {}, 0); while (id) clearInterval(id--); } catch {}
                rafOrig = window.requestAnimationFrame; toOrig = window.setTimeout; intOrig = window.setInterval;
                window.requestAnimationFrame = () => 0;
                window.setTimeout = () => 0;
                window.setInterval = () => 0;
                window.__frozenTimers = { rafOrig, toOrig, intOrig };
            }
            setBtnVisual(true, btn, hint);
        }

        // Unfreezes the page and restores original state
        function unfreeze(force = false) {
            if (!isFrozen && !force) return;
            isFrozen = false; window.__freezeIsFrozen = false;

            unfreezeAllHoveredStyles();

            restoreFns.forEach(fn => { try { fn(); } catch {} });
            restoreFns = []; styleElm?.remove(); styleElm = null;

            if (blockedTimers) {
                rafOrig && (window.requestAnimationFrame = rafOrig);
                toOrig && (window.setTimeout = toOrig);
                intOrig && (window.setInterval = intOrig);
            }
            setBtnVisual(false, btn, hint);
        }

        let pressT, drag = false, badge = null, sx = 0, sy = 0, sl = 0, st = 0;

        btn.addEventListener('pointerdown', e => {
            drag = false; sx = e.clientX; sy = e.clientY;
            const r = btn.getBoundingClientRect(); sl = r.left; st = r.top;

            pressT = setTimeout(() => {
                drag = true;
                btn.style.left = sl + 'px'; btn.style.top = st + 'px'; btn.style.right = '';
                btn.style.transition = 'none'; btn.style.cursor = 'grabbing';
                btn.style.zIndex = '2147483647';
                btn.setPointerCapture(e.pointerId);

                if (!badge) {
                    badge = document.createElement('span'); badge.textContent = '↕';
                    Object.assign(badge.style, {
                        position: 'absolute', top: '-8px', right: '-8px',
                        width: '20px', height: '20px', background: '#fff',
                        color: btn.dataset.dragColor, border: `2px solid ${btn.dataset.dragColor}`,
                        borderRadius: '50%', fontSize: '11px', lineHeight: '16px', fontWeight: '800',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        pointerEvents: 'none', boxShadow: '0 1px 4px rgba(0,0,0,.25)'
                    });
                    btn.append(badge);
                }
            }, LONG_PRESS);

            e.stopPropagation();
            if (e.cancelable) e.preventDefault();
        }, true);

        btn.addEventListener('pointermove', e => {
            if (!drag) return;
            btn.style.left = (sl + e.clientX - sx) + 'px';
            btn.style.top = (st + e.clientY - sy) + 'px';
        }, true);

        btn.addEventListener('pointerup', e => {
            clearTimeout(pressT);
            if (drag) {
                drag = false; btn.releasePointerCapture(e.pointerId);
                btn.style.transition = ''; btn.style.cursor = 'pointer';
                badge?.remove(); badge = null;
            } else {
                isFrozen ? unfreeze() : freeze();
            }
        }, true);

        const handleKeydown = e => {
            window.top.focus();
            if (!isFrozen && e.shiftKey && e.ctrlKey && !e.altKey &&
                (e.key === 'Shift' || e.key === 'Control')) {
                freeze();
                e.stopImmediatePropagation();
                e.preventDefault();
            } else if (isFrozen && (e.key === 'Escape' || e.code === 'Escape')) {
                unfreeze();
                e.stopImmediatePropagation();
                e.preventDefault();
            }
        };

        const registerKeydownListeners = () => {
            window.removeEventListener('keydown', handleKeydown, { capture: true });
            document.removeEventListener('keydown', handleKeydown, { capture: true });
            window.addEventListener('keydown', handleKeydown, { capture: true, passive: false });
            document.addEventListener('keydown', handleKeydown, { capture: true, passive: false });
        };

        registerKeydownListeners();

        setTimeout(() => { if (isFrozen) unfreeze(true); }, 6 * 60 * 1000);
    } else {
        fullUnfreeze(true);
    }
}

// Initialize
chrome.storage.local.get('freezeGlobalEnabled', ({ freezeGlobalEnabled }) => {
    setFreezeButton(freezeGlobalEnabled);
});
chrome.runtime.onMessage.addListener(msg => {
    if (msg?.action === 'toggle-freeze') setFreezeButton(msg.enabled);
});