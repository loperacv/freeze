// background.js - Handles extension installation and action toggle

// Initialize storage on extension install or update
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ freezeGlobalEnabled: false });
});

// Handle action (browser action) click to toggle freeze state
chrome.action.onClicked.addListener(async () => {
  try {
    const { freezeGlobalEnabled } = await chrome.storage.local.get('freezeGlobalEnabled');
    const enabled = !freezeGlobalEnabled;
    
    await chrome.storage.local.set({ freezeGlobalEnabled: enabled });
    
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.id) {
        try {
          await chrome.tabs.sendMessage(tab.id, { action: 'toggle-freeze', enabled });
        } catch (error) {}
      }
    }

    await chrome.action.setBadgeText({ text: enabled ? 'ON' : '' });
    await chrome.action.setBadgeBackgroundColor({ color: enabled ? '#00c853' : '#616161' });
  } catch (error) {}
});